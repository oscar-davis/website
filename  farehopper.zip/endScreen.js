function endScreen(){
    ambience.stop();
    background(255);
    textSize(72);
    fill('red');
    text('FARE HOPPED!',width/2, height/2);

    textSize(24);
    text('Coding: Oscar Davis',width/2, height/2 + 48);
    text('Game Design: Mirza Beg',width/2, height/2 + 96);
    text('Artwork: Ewan Whannel',width/2, height/2 + 144);
}
