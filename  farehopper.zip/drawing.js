//DRAWING FUNCTIONS
function drawMap(tile){
    for(var i = 0; i < tile.length; i++){
        tile[i].show();
    }
}
